var MD5 = require('../../../../utils/MD5.js');
var ExpressCodes = require('../../../../utils/kNexpressCode.js');
var queryExpress = require('../../../../utils/queryExpress.js');
const duration = 2000;
//OLAMI自然语言处理接口
const requestUrl = "https://cn.olami.ai/cloudservice/api";

const Appkey = "de03df6e10ce49c491d85d517a41c4c9";
const Appsecret = "0044d48597f14a9e81723f2c07129e94";
const api = "nli";
const ctx = wx.createCanvasContext('myCanvas');

// 语义处理所需的定义
const  OPT_QUERY=0x00;
const  OPT_QUERY_NUM=0x01;
const  OPT_QUERY_NAME=0x02;
const  OPT_QUERY_NUM_NAME=0x03;

const expressAPPname='expressage';
const expNumSlotName ='expnumber';
const expNameSlotName ='expname';

const exampleSentens = ['查快递','查快递3333481970033', '中通快递765325527325', '765325527325'];
//外接地址
const blogsite='http://blog.csdn.net/huangmeimao/article/details/74923621';



//语义处理公用变量定义
var expAppinfo=new expressInfo();

function expressInfo(object){
  this.OPT = OPT_QUERY_NUM; //默认通过运单编号查询
  this.numSlot=null;  //运单编号SLot
  this.nameSlot=null; //快递名称Slot
}
function resetExpInfo(){
  expAppinfo.OPT = OPT_QUERY_NUM; //默认通过运单编号查询
  expAppinfo.numSlot = null;  //运单编号SLot
  expAppinfo.nameSlot = null; //快递名称Slot
}
function APPSlot(){
  this.name = '';
  this.value='';
}
/**
 * 通过快递公司名查询公司编码
 */
function getExpCode(name){
  var actName=null;
  for (var item in expCodes) {
    if (item.indexOf(name) != -1) {  //item 表示Json串中的属性，如'name'  
      actName = item;
      break;
    }
  }
  return actName;
}
function HandleOLAMIresponseData(data, corpus, object)
{
     var textData='';//text文本框要show的内容
     var semantics = data.semantic;
     if (semantics == null || semantics.length==0){
       if (data.desc_obj.result != null && data.desc_obj.result.length != 0 && data.desc_obj.status==0)  {
         textData = data.desc_obj.result;
       }else
          textData='抱歉，我还理解不了你说的话。';
       object.setData({
         expresshead: '',
         text: textData
       })
       
     }else {

       for (var i = 0; i < semantics.length; i++) {
         var tempSem = data.semantic[0];
         if (tempSem.app == expressAPPname) { //仅处理快递模块的语义
           //处理modifier
           var mods = tempSem.modifier;
           if (mods.indexOf("query") > -1)
             expAppinfo.OPT = OPT_QUERY;
           else if (mods.indexOf("query_num") > -1)
             expAppinfo.OPT = OPT_QUERY_NUM;
           else if (mods.indexOf("query_name") > -1)
             expAppinfo.OPT = OPT_QUERY_NAME;
           else if (mods.indexOf("query_name_num") > -1)
             expAppinfo.OPT = OPT_QUERY_NUM_NAME;

           //获取slots,即快递公司名称和运单号
           var slots = tempSem.slots;
           if (slots != null) {
             for (var j = 0; j < slots.length; j++) {
               var tempslot = slots[j];
               if (tempslot.name == expNumSlotName) { //运单号
                 var numslot = new APPSlot();
                 numslot.name = expNumSlotName;
                 numslot.value = tempslot.value;
                 expAppinfo.numSlot = numslot;
               } else if (tempslot.name == expNameSlotName) {//快递名称
                 var nameslot = new APPSlot();
                 nameslot.name = expNumSlotName;
                 nameslot.value = tempslot.value;
                 expAppinfo.nameSlot = nameslot;
               }

             }

           }
           //handle Operations
           switch (expAppinfo.OPT) {
      
             case OPT_QUERY:
               textData = '请提供您的运单编号。';
               object.setData({
                 expresshead: '',
                 text: textData
               })
               break;
             case OPT_QUERY_NUM:
             //检测是否存在快递名称
               if (expAppinfo.nameSlot != null && expAppinfo.numSlot != null){ //采用快递编号+快递公司方式查询
                 //获取快递公司名称
                 var expname = getExpCode(expAppinfo.nameSlot.value);
                 var expcode = expCodes[expname];
                 queryExpress.queryExpress(expname,expcode, expAppinfo.numSlot.value, object);
               } else if (expAppinfo.numSlot != null){
                  //用运单编号查询
                 queryExpress.queryEXPbyNum(expAppinfo.numSlot.value, object);
               }
               resetExpInfo(object);
               break;
             case OPT_QUERY_NAME:
               textData = '请提供您的运单编号。';
               object.setData({
                 expresshead: '',
                 text: textData
               })
               break;
             case OPT_QUERY_NUM_NAME:
               if (expAppinfo.nameSlot != null && expAppinfo.numSlot != null) { //采用快递编号+快递公司方式查询
                 //获取快递公司名称
                 var expname = getExpCode(expAppinfo.nameSlot.value);
                 var expcode = expCodes[expname];
                 queryExpress.queryExpress(expname,expcode, expAppinfo.numSlot.value, object);
               }
               resetExpInfo(object);
               break;
           }

           break;

         }
       }
     }
     
     

}

function parseCorpus(corpus,object) {

  //暂时注释掉访问olami代码
  //获取sign的MD5值
  object.setData({
    text: '请稍后......'
  })
  var timestamp = new Date().getTime();

  var originalSign = Appsecret + "api=" + api + "appkey=" + Appkey + "timestamp=" + timestamp + Appsecret;
  var sign = MD5.md5(originalSign);

  var rqdata = { "data": { "input_type": 1, "text": corpus }, "data_type": "stt" };
  console.log(JSON.stringify(rqdata))
  console.log('\r\n')
  wx.request({
    url: requestUrl,
    data: {
      appkey: Appkey,
      api: api,
      timestamp: timestamp,
      sign: sign,
      rq: JSON.stringify(rqdata),
      cusid: "11223344"
    },
    header: {
      'content-type': 'application/x-www-form-urlencoded'
    },
    method: 'POST',
    success: function (result) {

      var data = result.data.data;
      HandleOLAMIresponseData(data.nli[0], corpus, object);
      console.log('有效数据', result.data);
      console.log('success data', result.data)
    },

    fail: function ({errMsg}) {
      console.log('request fail', errMsg)
      object.setData({
        text: 'ERROR'
      })
    }
  })


};

Page({
  data: {
    focus: false,
    inputValue: '',
    canAdd: true,
    canRemove: false,
    text: '',
    expresshead:'',
    searchinput:'',
    buttonValue:'查询',
    isDisableInput:false
  },



  ResearchHelp: function (e) {
    wx.showModal({
      title: '复制下面的链接在浏览器中打开即可',
      content: blogsite,
      showCancel:false,
      confirmText:'复制',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          //复制内容到剪切板
          wx.setClipboardData({
            data: blogsite,
            success: function (res) {
              wx.getClipboardData({
                success: function (res) {
                  //打印剪切板的内容
                  console.log(res.data) 
                }
              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })  

  },
  DisplayExamplesSentens:function(e){

    var that = this;
    wx.showActionSheet({
      itemList: exampleSentens,
      itemColor:'#dd7e6b',
      success: function (res) {
        if (res.tapIndex != null) {
          var corpus = exampleSentens[res.tapIndex];
          parseCorpus(corpus, that);
        }
        console.log(res.tapIndex)
      },
      fail: function (res) {
        console.log(res.errMsg)
      }
    })
  },
  acquire_input:function(e){
    this.setData({
      inputValue: e.detail.value
    })
  },
  BeginSearch:function(e){
   
    this.setData({
      searchinput: '',
    })
    parseCorpus(this.data.inputValue, this);
  },
  bindConfirmControl: function (e) {

    var corpus = e.detail.value;

    this.setData({
      searchinput: '',
    })
    parseCorpus(corpus,this);
  },
  bindReplaceInput: function (e) {
    var value = e.detail.value
    var pos = e.detail.cursor
    var left
    if (pos !== -1) {
      // 光标在中间
      left = e.detail.value.slice(0, pos)
      // 计算光标的位置
      pos = left.replace(/11/g, '2').length
    }

    // 直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
    return {
      value: value.replace(/11/g, '2'),
      cursor: pos
    }

    // 或者直接返回字符串,光标在最后边
    // return value.replace(/11/g,'2'),
  },
  switchChange: function (e) {
    console.log('switch1 发生 change 事件，携带值为', e.detail.value)
    if (e.detail.value){
      
      this.setData({
        buttonValue: '查询',
        isDisableInput:false
      })
    }else{
      this.setData({
        buttonValue: '录音',
        isDisableInput: true //录音时输入框不可用
      })
    }
         
  },

  bindHideKeyboard: function (e) {
    if (e.detail.value === '123') {
      // 收起键盘
      wx.hideKeyboard()
    }
  }
})


var expCodes = {
  安捷快递: 'AJ',
  安能物流: 'ANE',
  安信达快递: 'AXD',
  北青小红帽: 'BQXHM',
  百福东方: '	BFDF',
  百世快运: '	BTWL',
  CCES快递: 'CCES',
  城市100: 'CITY100',
  COE东方快递: 'COE',
  长沙创一: 'CSCY',
  成都善途速运: 'CDSTKY',
  德邦: 'DBL',
  D速物流: 'DSWL',
  大田物流: 'DTWL',
  EMS: 'EMS',
  快捷速递: 'FAST',
  FEDEX联邦国: 'FEDEX',
  FEDEX联邦国际: 'FEDEX_GJ',
  飞康达: 'FKD',
  广东邮政: 'GDEMS',
  共速达: 'GSD',
  国通快递: 'GTO',
  高铁速递: 'GTSD',
  汇丰物流: 'HFWL',
  天天快递: 'HHTT',
  恒路物流: 'HLWL',
  天地华宇: 'HOAU',
  华强物流: 'hq568',
  百世快递: 'HTKY',
  华夏龙物流: 'HXLWL',
  好来运快递: 'HYLSD',
  京广速递: 'JGSD',
  九曳供应链: 'JIUYE',
  佳吉快运: '	JJKY',
  嘉里物流: 'JLDT',
  捷特快递: 'JTKD',
  急先达: 'JXD',
  晋越快递: 'JYKD',
  加运美: 'JYM',
  佳怡物流: 'JYWL',
  跨越物流: 'KYWL',
  龙邦快递: 'LB',
  联昊通速递: 'LHT',
  民航快递: 'MHKD',
  明亮物流: 'MLWL',
  能达速递: 'NEDA',
  平安达腾飞快递: 'PADTF',
  全晨快递: 'QCKD',
  全峰快递: 'QFKD',
  全日通快递: 'QRT',
  如风达: 'RFD',
  赛澳递: 'SAD',
  圣安物流: 'SAWL',
  盛邦物流: 'SBWL',
  上大物流: 'SDWL',
  顺丰快递: 'SF',
  盛丰物流: 'SFWL',
  盛辉物流: 'SHWL',
  速通物流: 'ST',
  申通快递: 'STO',
  速腾快递: 'STWL',
  速尔快递: 'SURE',
  唐山申通: 'TSSTO',
  全一快递: 'UAPEX',
  优速快递: 'UC',
  万家物流: 'WJWL',
  万象物流: 'WXWL',
  新邦物流: 'XBWL',
  信丰快递: 'XFEX',
  希优特: 'XYT',
  新杰物流: 'XJ',
  源安达快递: 'YADEX',
  远成物流: 'YCWL',
  韵达快递: 'YD',
  义达国际物流: 'YDH',
  越丰物流: 'YFEX',
  原飞航物流: 'YFHEX',
  亚风快递: 'YFSD',
  运通快递: 'YTKD',
  圆通速递: 'YTO',
  亿翔快递: 'YXKD',
  邮政平邮小包: 'YZPY',
  增益快递: 'ZENY',
  汇强快递: 'ZHQKD',
  宅急送: 'ZJS',
  众通快递: 'ZTE',
  中铁快运: 'ZTKY',
  中通速递: 'ZTO',
  中铁物流: 'ZTWL',
  中邮物流: 'ZYWL',
  亚马逊物流: 'AMAZON',
  速必达物流: 'SUBIDA',
  瑞丰速递: 'RFEX',
  快客快递: '	QUICK',
  城际快递: 'CJKD',
  CNPEX中邮快递: 'CNPEX',
  鸿桥供应链: 'HOTSCM',
  海派通物流公司: 'HPTEX',
  澳邮专线: 'AYCA',
  泛捷快递: 'PANEX',
  PCAExpress: 'PCA',
  UEQExpress: 'UEQ'

};