var MD5 = require('../../../../utils/MD5.js');
var GUID = require('../../../../utils/GUID.js');

var queryExpress = require('../../../../utils/queryExpress.js');

//OLAMI自然语言处理接口
const requestUrl = "https://cn.olami.ai/cloudservice/api";

const Appkey = "de03df6e10ce49c491d85d517a41c4c9";
const Appsecret = "0044d48597f14a9e81723f2c07129e94";
const api = "nli";

//聊天的API key信息
const ChatAppkey = '459708c3317143209c35b1881d9eb24a';
const ChatAppsecret ='e023b671a1144fa4a8d9e572a49b78eb';

// 语义处理所需的常量
const  OPT_QUERY=0x00;
const  OPT_QUERY_NUM=0x01;
const  OPT_QUERY_NAME=0x02;
const  OPT_QUERY_NUM_NAME=0x03;

const expressAPPname='expressage';
const expNumSlotName ='expnumber';
const expNameSlotName ='expname';

const searchbuttonvalue_default="查快递"
const searchbuttonvalue_switch='聊天'

//查快递的例句
var expEXnum=1;
var exampleSentens = [];
const exampleSentens1 = ['查快递','查快递3333481970033', '中通快递765325527325', '765325527325'];
const exampleSentens2 = ['查一下快递', '帮我查快递3333481970033', '中通快递765325527325查一下', '我的运单12425555到哪'];
const exampleSentens3 = ['看看我的快递到哪儿了', '申通快递3333481970033帮我查查', '查一下运单号439307684430', '我的运单是12425555'];

//聊天的例句
var chatNum=1;
var exampleChatSentens = [];
const exampleChatSentens1 = ['我最喜欢你了', '宫爆鸡丁的做法','3乘以50再加100等于几', '今天周几啊', '帮我算一下24点','给我讲个笑话呗'];
const exampleChatSentens2 = ['你叫什么名字啊', '孜然羊肉怎么做', '1加1等于几', '中秋节是几号', '会算24点吗', '讲一个笑话'];
const exampleChatSentens3 = ['你喜欢吃冰激凌吗', ' 你知道怎么做排骨吗', '今天几号', '1,5,6,8算一下24点', '讲个故事听听呗'];
const exampleChatSentens4 = ['你最喜欢谁啊', '牛肉怎么做好吃', '你会算乘法吗', '下个月有几天', '2,3,8和9怎样算24点', '来个幽默的笑话听听'];
const exampleChatSentens5 = ['世界上谁最漂亮啊', '小炒肉怎么做好吃', '加减乘除会不会啊', '国庆节怎么放假', '算算24点', '我想听故事'];

//外接地址
const blogsite='http://blog.csdn.net/huangmeimao/article/details/74923621';

//查询方式
const search_type=0x00;
const chat_type=0x01;

//API访问失败等不正常情况的提示
const API_data_error='亲爱的，估计服务器罢工了，快联系我主人吧。';
const API_Fail='我崩溃了，您待会再来吧';

//标题框初始化内容
const titletext_default='您可以使用自然语言查询快递，点开例句试试吧。'
const Chattype_text = '本宝宝支持聊天、菜谱、日历、计算、24点和讲笑话哦。点开例句试试吧';

var userId = GUID.NewGuid();

//语义处理公用变量定义
var expAppinfo=new expressInfo();

function expressInfo(object){
  this.OPT = OPT_QUERY_NUM; //默认通过运单编号查询
  this.numSlot=null;  //运单编号SLot
  this.nameSlot=null; //快递名称Slot
}
function resetExpInfo(){
  expAppinfo.OPT = OPT_QUERY_NUM; //默认通过运单编号查询
  expAppinfo.numSlot = null;  //运单编号SLot
  expAppinfo.nameSlot = null; //快递名称Slot
}
function APPSlot(){
  this.name = '';
  this.value='';
}
/**
 * 通过快递公司名查询公司编码
 */
function getExpCode(name){
  var actName=null;
  for (var item in expCodes) {
    if (item.indexOf(name) != -1) {  //item 表示Json串中的属性，如'name'  
      actName = item;
      break;
    }
  }
  return actName;
}
/**
 * 处理OLAMI语义API的回复内容
 */
function HandleOLAMIresponseData(data, corpus, object)
{
     var textData='';  //text文本框要show的内容
     var semantics = data.semantic;
     if (semantics == null || semantics.length==0){
       if (data.desc_obj.result != null && data.desc_obj.result.length != 0 && data.desc_obj.status==0)  {
         if (data.type == 'joke' || data.type == 'cooking'){
           textData = data.data_obj[0].content;
         }else
           textData = data.desc_obj.result;

       }else
          textData='抱歉，我还理解不了你说的话。';
       object.setData({
         expresshead: '',
         text: textData
       })
       
     }else {

       for (var i = 0; i < semantics.length; i++) {
         var tempSem = data.semantic[0];
         if (tempSem.app == expressAPPname) { //仅处理快递模块的语义
           //处理modifier
           var mods = tempSem.modifier;
           if (mods.indexOf("query") > -1)
             expAppinfo.OPT = OPT_QUERY;
           else if (mods.indexOf("query_num") > -1)
             expAppinfo.OPT = OPT_QUERY_NUM;
           else if (mods.indexOf("query_name") > -1)
             expAppinfo.OPT = OPT_QUERY_NAME;
           else if (mods.indexOf("query_name_num") > -1)
             expAppinfo.OPT = OPT_QUERY_NUM_NAME;

           //获取slots,即快递公司名称和运单号
           var slots = tempSem.slots;
           if (slots != null) {
             for (var j = 0; j < slots.length; j++) {
               var tempslot = slots[j];
               if (tempslot.name == expNumSlotName) { //运单号
                 var numslot = new APPSlot();
                 numslot.name = expNumSlotName;
                 numslot.value = tempslot.value;
                 expAppinfo.numSlot = numslot;
               } else if (tempslot.name == expNameSlotName) {//快递名称
                 var nameslot = new APPSlot();
                 nameslot.name = expNumSlotName;
                 nameslot.value = tempslot.value;
                 expAppinfo.nameSlot = nameslot;
               }

             }

           }
           //handle Operations
           switch (expAppinfo.OPT) {
      
             case OPT_QUERY:
               textData = '请提供您的运单编号。';
               object.setData({
                 expresshead: '',
                 text: textData
               })
               break;
             case OPT_QUERY_NUM:
             //检测是否存在快递名称
               if (expAppinfo.nameSlot != null && expAppinfo.numSlot != null){ //采用快递编号+快递公司方式查询
                 //获取快递公司名称
                 var expname = getExpCode(expAppinfo.nameSlot.value);
                 var expcode = expCodes[expname];
                 queryExpress.queryExpress(expname,expcode, expAppinfo.numSlot.value, object);
               } else if (expAppinfo.numSlot != null){
                  //用运单编号查询
                 queryExpress.queryEXPbyNum(expAppinfo.numSlot.value, object);
               }
               resetExpInfo(object);
               break;
             case OPT_QUERY_NAME:
               textData = '请提供您的运单编号。';
               object.setData({
                 expresshead: '',
                 text: textData
               })
               break;
             case OPT_QUERY_NUM_NAME:
               if (expAppinfo.nameSlot != null && expAppinfo.numSlot != null) { //采用快递编号+快递公司方式查询
                 //获取快递公司名称
                 var expname = getExpCode(expAppinfo.nameSlot.value);
                 var expcode = expCodes[expname];
                 queryExpress.queryExpress(expname,expcode, expAppinfo.numSlot.value, object);
               }
               resetExpInfo(object);
               break;
           }

           break;

         }
       }
     }
     
     

}
/**
 * 将输入语句通过post方式提交到OLAMI语义开放平台
 */
function parseCorpus(corpus,object) {
  var usekey = Appkey;
  var usesecret = Appsecret;
  if (object.data.dialogtype == chat_type){
    usekey = ChatAppkey;
    usesecret = ChatAppsecret;
  }

  //获取sign的MD5值
  object.setData({
    text: '请稍后......'
  })
  var timestamp = new Date().getTime();

  var originalSign = usesecret + "api=" + api + "appkey=" + usekey + "timestamp=" + timestamp + usesecret;
  var sign = MD5.md5(originalSign);

  var rqdata = { "data": { "input_type": 1, "text": corpus }, "data_type": "stt" };
  console.log(JSON.stringify(rqdata))
  console.log('\r\n')
  wx.request({
    url: requestUrl,
    data: {
      appkey: usekey,
      api: api,
      timestamp: timestamp,
      sign: sign,
      rq: JSON.stringify(rqdata),
      cusid: userId,
      changebuttoncolor: "#d0e0e3"
    },
    header: {
      'content-type': 'application/x-www-form-urlencoded'
    },
    method: 'POST',
    success: function (result) {
      var data = result.data.data;
      if (result.data != null && result.data.status!=null&&result.data.status=='ok'){
        HandleOLAMIresponseData(data.nli[0], corpus, object);
        console.log('欧拉蜜有效数据', result.data);
      }else{
        console.log('欧拉蜜返回失败', result.data.status);       
        object.setData({
          text: API_data_error
        })
      }
    },

    fail: function ({errMsg}) {
      console.log('request fail', errMsg)
      object.setData({
        text: API_data_error
      })
    }
  })


};


Page({
  data: {
    inputValue: '', //用于显示输入语句
    text: '', //查询结果显示
    expresshead: titletext_default, //查询标题显示
    searchinput:'', //用户输入的查询语句
    buttonValue: searchbuttonvalue_default, //查询按钮的默认值
    isDisableInput:false, //输入框是否可用
    dialogtype:search_type //工具公式，默认是查询模式
  },
/**
 * 指定帮助连接
 */
  ResearchHelp: function (e) {
    if (this.data.dialogtype == search_type){
    switch (expEXnum){
      case 1:
        expEXnum=2;
        exampleSentens = exampleSentens2;
        break;
      case 2:
        expEXnum = 3;
        exampleSentens = exampleSentens3;
        break;
      case 3:
        expEXnum = 1;
        exampleSentens = exampleSentens1;
        break;    
       }
    } else if (this.data.dialogtype == chat_type){
      switch (chatNum) {
        case 1:
          chatNum = 2;
          exampleChatSentens = exampleChatSentens2;
          break;
        case 2:
          chatNum = 3;
          exampleChatSentens = exampleChatSentens3;
          break;
        case 3:
          chatNum = 4;
          exampleChatSentens = exampleChatSentens4;
          break;
        case 4:
          chatNum = 5;
          exampleChatSentens = exampleChatSentens5;
          break;
        case 5:
          chatNum = 1;
          exampleChatSentens = exampleChatSentens1;
          break;
      }
    }
    wx.showToast({
      title: '好了',
      icon: 'success',
      duration: 800
    })
/*   //暂时去掉该功能
    wx.showModal({
      title: '复制下面的链接在浏览器中打开即可',
      content: blogsite,
      showCancel:false,
      confirmText:'复制',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          //复制内容到剪切板
          wx.setClipboardData({
            data: blogsite,
            success: function (res) {
              wx.getClipboardData({
                success: function (res) {
                  //打印剪切板的内容
                  console.log(res.data) 
                }
              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })  
*/
  },
  /**
   * 例句选取
   */
  DisplayExamplesSentens:function(e){
    var sentenlist = exampleSentens;
    if (this.data.dialogtype==chat_type)
        sentenlist = exampleChatSentens;
    var that = this;
    wx.showActionSheet({
      itemList: sentenlist,
      itemColor:'#dd7e6b',
      success: function (res) {
        if (res.tapIndex != null) {
          var corpus = sentenlist[res.tapIndex];
          parseCorpus(corpus, that);
        }
        console.log(res.tapIndex)
      },
      fail: function (res) {
        //console.log(res.errMsg)
      }
    })
  },
  /**
   * 实时输出用户输入的句子
   */
  acquire_input:function(e){
    this.setData({
      inputValue: e.detail.value
    })
  },
  /**
   * 对应“查询”button
   */
  BeginSearch:function(e){
   
    this.setData({
      searchinput: '',
    })
    parseCorpus(this.data.inputValue, this);

  },
  /**
   * 当用户输入完语句，确认时直接查询
   */
  bindConfirmControl: function (e) {

    var corpus = e.detail.value;

    this.setData({
      searchinput: '',
    })
    parseCorpus(corpus,this);
  },
 /**
  * 功能切换，分为聊天和查询两种模式
  */
  switchChange: function (e) {  
    if (e.detail.value){
      
      this.setData({
        buttonValue: searchbuttonvalue_default,
        isDisableInput:false,
        dialogtype: search_type, //查询模式
        text:'',
        expresshead: titletext_default
        
      })
    }else{
      this.setData({
        buttonValue: searchbuttonvalue_switch,
        isDisableInput: false,
        dialogtype: chat_type, //聊天模式
        text:'',
        expresshead: Chattype_text
      })
    }
         
  },
  onLoad: function () {
   console.log('1111:' + userId);
   exampleSentens = exampleSentens1;
   exampleChatSentens = exampleChatSentens1;
   this.data.changebuttoncolor='red';
  }
})

/**
 * 快递码数据表
 */
var expCodes = {
  安捷快递: 'AJ',
  安能物流: 'ANE',
  安信达快递: 'AXD',
  北青小红帽: 'BQXHM',
  百福东方: '	BFDF',
  百世快运: '	BTWL',
  CCES快递: 'CCES',
  城市100: 'CITY100',
  COE东方快递: 'COE',
  长沙创一: 'CSCY',
  成都善途速运: 'CDSTKY',
  德邦: 'DBL',
  D速物流: 'DSWL',
  大田物流: 'DTWL',
  EMS: 'EMS',
  快捷速递: 'FAST',
  FEDEX联邦国: 'FEDEX',
  FEDEX联邦国际: 'FEDEX_GJ',
  飞康达: 'FKD',
  广东邮政: 'GDEMS',
  共速达: 'GSD',
  国通快递: 'GTO',
  高铁速递: 'GTSD',
  汇丰物流: 'HFWL',
  天天快递: 'HHTT',
  恒路物流: 'HLWL',
  天地华宇: 'HOAU',
  华强物流: 'hq568',
  百世快递: 'HTKY',
  华夏龙物流: 'HXLWL',
  好来运快递: 'HYLSD',
  京广速递: 'JGSD',
  九曳供应链: 'JIUYE',
  佳吉快运: '	JJKY',
  嘉里物流: 'JLDT',
  捷特快递: 'JTKD',
  急先达: 'JXD',
  晋越快递: 'JYKD',
  加运美: 'JYM',
  佳怡物流: 'JYWL',
  跨越物流: 'KYWL',
  龙邦快递: 'LB',
  联昊通速递: 'LHT',
  民航快递: 'MHKD',
  明亮物流: 'MLWL',
  能达速递: 'NEDA',
  平安达腾飞快递: 'PADTF',
  全晨快递: 'QCKD',
  全峰快递: 'QFKD',
  全日通快递: 'QRT',
  如风达: 'RFD',
  赛澳递: 'SAD',
  圣安物流: 'SAWL',
  盛邦物流: 'SBWL',
  上大物流: 'SDWL',
  顺丰快递: 'SF',
  盛丰物流: 'SFWL',
  盛辉物流: 'SHWL',
  速通物流: 'ST',
  申通快递: 'STO',
  速腾快递: 'STWL',
  速尔快递: 'SURE',
  唐山申通: 'TSSTO',
  全一快递: 'UAPEX',
  优速快递: 'UC',
  万家物流: 'WJWL',
  万象物流: 'WXWL',
  新邦物流: 'XBWL',
  信丰快递: 'XFEX',
  希优特: 'XYT',
  新杰物流: 'XJ',
  源安达快递: 'YADEX',
  远成物流: 'YCWL',
  韵达快递: 'YD',
  义达国际物流: 'YDH',
  越丰物流: 'YFEX',
  原飞航物流: 'YFHEX',
  亚风快递: 'YFSD',
  运通快递: 'YTKD',
  圆通速递: 'YTO',
  亿翔快递: 'YXKD',
  邮政平邮小包: 'YZPY',
  增益快递: 'ZENY',
  汇强快递: 'ZHQKD',
  宅急送: 'ZJS',
  众通快递: 'ZTE',
  中铁快运: 'ZTKY',
  中通速递: 'ZTO',
  中铁物流: 'ZTWL',
  中邮物流: 'ZYWL',
  亚马逊物流: 'AMAZON',
  速必达物流: 'SUBIDA',
  瑞丰速递: 'RFEX',
  快客快递: '	QUICK',
  城际快递: 'CJKD',
  CNPEX中邮快递: 'CNPEX',
  鸿桥供应链: 'HOTSCM',
  海派通物流公司: 'HPTEX',
  澳邮专线: 'AYCA',
  泛捷快递: 'PANEX',
  PCAExpress: 'PCA',
  UEQExpress: 'UEQ'

};